var productId, searchTxt, searchBy, categoryId, alternateCategoryId, categoryName, alternateCategoryName;
var images = [];
var dataRow;
define("userfrmImagesController", {
    //Type your controller code here 
    onNavigate: function(eventobject) {
        images = eventobject.images;
        productId = eventobject.productId;
        searchTxt = eventobject.searchTxt;
        searchBy = eventobject.searchBy;
        categoryId = eventobject.categoryId;
        alternateCategoryId = eventobject.alternateCategoryId;
        categoryName = eventobject.categoryName;
        alternateCategoryName = eventobject.alternateCategoryName;
        this.view.lblProductName.text = eventobject.productName;
        //alert("images "+JSON.stringify(images));
        this.view.ComHeader.imgSearch.setVisibility(false);
        //this.view.segImages.removeAll();
    },
    preShowGuys: function() {
        for (let i = 0; i < images.length - 1; i++) {
            dataRow = {
                imgProduct: images[i].href
            };
            this.view.segImages.addDataAt(dataRow, i);
        }
    },
    previousForm: function() {
        var navigationObject = new kony.mvc.Navigation("frmProductDetail");
        var navigationContext = {
            "productId": productId,
            "searchTxt": searchTxt,
            "searchBy": searchBy,
            "categoryId": categoryId,
            "alternateCategoryId": alternateCategoryId,
            "categoryName": categoryName,
            "alternateCategoryName": alternateCategoryName
        };
        navigationObject.navigate(navigationContext);
        kony.application.destroyForm("frmImages");
    },
    goHome: function() {
        var navigationObject = new kony.mvc.Navigation("frmMain");
        var navigationContext = {};
        navigationObject.navigate(navigationContext);
    }
});
define("frmImagesControllerActions", {
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** onTouchStart defined for imgBack **/
    AS_Image_c47f0ec985ae4f0b920901c1afcfead2: function AS_Image_c47f0ec985ae4f0b920901c1afcfead2(eventobject, x, y) {
        var self = this;
        return self.previousForm.call(this);
    },
    /** preShow defined for frmImages **/
    AS_Form_fed44dc74ced4c2e9adbb19991b24cb1: function AS_Form_fed44dc74ced4c2e9adbb19991b24cb1(eventobject) {
        var self = this;
        return self.preShowGuys.call(this);
    },
    /** onNavigate defined for frmImages **/
    onNavigate: function AS_Form_b37e7d2a1acb4d84b6e4edf3bfccbcee(eventobject) {
        var self = this;
        return self.onNavigate.call(this, null);
    },
    /** onDeviceBack defined for frmImages **/
    AS_Form_h78ee8ddb95d49c39b5bbfeeabde16ec: function AS_Form_h78ee8ddb95d49c39b5bbfeeabde16ec(eventobject) {
        var self = this;
        return self.previousForm.call(this);
    },
    /** onDeviceBack defined for frmImages **/
    AS_Form_gc3b5353f1d74f17b7a203db72579e1a: function AS_Form_gc3b5353f1d74f17b7a203db72579e1a(eventobject) {
        var self = this;
        return self.previousForm.call(this);
    }
});
define("frmImagesController", ["userfrmImagesController", "frmImagesControllerActions"], function() {
    var controller = require("userfrmImagesController");
    var controllerActions = ["frmImagesControllerActions"];
    return kony.visualizer.mixinControllerActions(controller, controllerActions);
});
