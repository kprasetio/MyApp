define("frmMain", function() {
    return function(controller) {
        function addWidgetsfrmMain() {
            this.setDefaultUnit(kony.flex.DP);
            var flxSearch = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxSearch",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "CopyslFbox0fa2858e7906a4a",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {}, {});
            flxSearch.setDefaultUnit(kony.flex.DP);
            var flxSHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "8%",
                "id": "flxSHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "CopyslFbox0ce15b1f6f19e4c",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {}, {});
            flxSHeader.setDefaultUnit(kony.flex.DP);
            var txtSearch = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "centerY": "50%",
                "focusSkin": "CopydefTextBoxFocus0ae72938d5e824e",
                "height": "40dp",
                "id": "txtSearch",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "9dp",
                "onDone": controller.AS_TextField_b353877479be4573b320057480c035e6,
                "secureTextEntry": false,
                "skin": "CopydefTextBoxNormal0cdbd09ed8ab14a",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "0dp",
                "width": "300dp",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoComplete": false,
                "autoCorrect": false,
                "placeholderSkin": "defTextBoxPlaceholder"
            });
            var lblCancelSearch = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblCancelSearch",
                "isVisible": true,
                "left": "329dp",
                "onTouchStart": controller.AS_Label_ada3081453ef4e7ca3b5f78df87cb09a,
                "skin": "CopydefLabel0cee13c2ec2be49",
                "text": "Cancel",
                "textStyle": {},
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            flxSHeader.add(txtSearch, lblCancelSearch);
            var FlexContainer0c6ee9d0a23354f = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "FlexContainer0c6ee9d0a23354f",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "CopyslFbox0f14f55c57c5c4a",
                "width": "100%",
                "zIndex": 1
            }, {}, {});
            FlexContainer0c6ee9d0a23354f.setDefaultUnit(kony.flex.DP);
            FlexContainer0c6ee9d0a23354f.add();
            flxSearch.add(flxSHeader, FlexContainer0c6ee9d0a23354f);
            var ComHeader = new com.pras.sertificate.BasicForm.ComHeader({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "8%",
                "id": "ComHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "CopyslFbox0a5d876da8d774a",
                "top": "0dp",
                "width": "100%",
                "overrides": {
                    "ComHeader": {
                        "bottom": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared",
                        "left": "0dp",
                        "right": "viz.val_cleared",
                        "top": "0dp"
                    },
                    "imgBack": {
                        "src": "ic_menu_back.png"
                    },
                    "imgLogo": {
                        "src": "bestbuy.png"
                    },
                    "imgSearch": {
                        "src": "search.png"
                    }
                }
            }, {
                "overrides": {}
            }, {
                "overrides": {}
            });
            ComHeader.imgBack.onTouchStart = controller.AS_Image_f09267e962ce4d99b33d59d40254904f;
            ComHeader.imgLogo.onTouchStart = controller.AS_Image_a1daf5135fc949f591e5ea0b696983a4;
            ComHeader.imgSearch.onTouchStart = controller.AS_Image_g475e7ec1f754c3384179850424a02ef;
            var flxMain = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "92%",
                "id": "flxMain",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "CopyslFbox0acb22120a29040",
                "top": "8%",
                "width": "100%",
                "zIndex": 1
            }, {}, {});
            flxMain.setDefaultUnit(kony.flex.DP);
            var flxPath = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "6%",
                "id": "flxPath",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {}, {});
            flxPath.setDefaultUnit(kony.flex.DP);
            var lblPath = new kony.ui.Label({
                "centerY": "50%",
                "height": "100%",
                "id": "lblPath",
                "isVisible": true,
                "left": "4dp",
                "skin": "CopydefLabel0e9843c3dc65443",
                "textStyle": {},
                "top": "0dp",
                "width": "98%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            flxPath.add(lblPath);
            var flxData = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "93%",
                "id": "flxData",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "2%",
                "isModalContainer": false,
                "skin": "CopyslFbox0j725d53d355d4e",
                "top": "0dp",
                "width": "96%"
            }, {}, {});
            flxData.setDefaultUnit(kony.flex.DP);
            var segData = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "data": [{
                    "lblCategory": "",
                    "lblCategoryId": ""
                }],
                "groupCells": false,
                "height": "100%",
                "id": "segData",
                "isVisible": true,
                "left": "0dp",
                "needPageIndicator": true,
                "onRowClick": controller.AS_Segment_ebf3d6063c3f43e5ae1d805ad77eb285,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowFocusSkin": "seg2Focus",
                "rowSkin": "Copyseg0g94edda7b3da44",
                "rowTemplate": "flxItems",
                "scrollingEvents": {},
                "sectionHeaderSkin": "sliPhoneSegmentHeader",
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorRequired": false,
                "showScrollbars": true,
                "top": "0dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "flxItems": "flxItems",
                    "lblCategory": "lblCategory",
                    "lblCategoryId": "lblCategoryId"
                },
                "width": "100%",
                "zIndex": 1
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxData.add(segData);
            flxMain.add(flxPath, flxData);
            var flxSeparator = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1dp",
                "id": "flxSeparator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": 0,
                "isModalContainer": false,
                "skin": "CopyslFbox0fcbfccaf7dbe4f",
                "top": "8%",
                "width": "100%",
                "zIndex": 1
            }, {}, {});
            flxSeparator.setDefaultUnit(kony.flex.DP);
            flxSeparator.add();
            this.add(flxSearch, ComHeader, flxMain, flxSeparator);
        };
        return [{
            "addWidgets": addWidgetsfrmMain,
            "enabledForIdleTimeout": false,
            "id": "frmMain",
            "init": controller.AS_Form_b69f9f94b39c41c985e58539f70ae06d,
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "postShow": controller.AS_Form_e57f0f11d0534358b2126d203a924a0b,
            "skin": "slBgForm"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "onDeviceBack": controller.AS_Form_f7cd907ff16845ed89b5c723f273d295,
            "retainScrollPosition": false
        }]
    }
});