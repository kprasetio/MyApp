var productId;
var productSKU;
var searchTxt;
var searchBy;
var categoryId;
var alternateCategoryId;
var categoryName;
var alternateCategoryName;
var images;
define("userfrmProductDetailController", {
    //Type your controller code here  getProduct : function() {
    onNavigate: function(eventobject) {
        productId = eventobject.productId;
        searchTxt = eventobject.searchTxt;
        searchBy = eventobject.searchBy;
        categoryId = eventobject.categoryId;
        alternateCategoryId = eventobject.alternateCategoryId;
        categoryName = eventobject.categoryName;
        alternateCategoryName = eventobject.alternateCategoryName;
        // alert("searchBy >> "+ JSON.stringify(searchBy));
        this.getProduct();
    },
    getProduct: function() {
        var integrationServiceObject = kony.sdk.getCurrentInstance().getIntegrationService("BestBuyService");
        var headers = {};
        var input = {
            "productId": productId
        };
        integrationServiceObject.invokeOperation("getProductDetails", headers, input, this.getProductDetailsSuccessCallback.bind(this), this.getProductDetailsFailurCallback.bind(this));
        this.view.ComHeader.imgSearch.setVisibility(false);
        this.view.flxProduct.setVisibility(false);
        this.view.segReviews.setVisibility(false);
    },
    getProductDetailsSuccessCallback: function(response) {
        if (response.opstatus === 0 && response !== null) {
            //try {    
            var product = response.product;
            images = response.images;
            if (product !== null) {
                //alert("name"+ JSON.stringify(product.name));
                this.view.lblProduct.text = product.name;
                this.view.lblMore.setVisibility(false);
                if (images.length > 0) {
                    this.view.imgProduct.src = images[0].href;
                    if (images.length > 1) {
                        this.view.lblMore.setVisibility(true);
                    }
                }
                if (product.onSale == 'false') {
                    this.view.lblPrice.text = 'Price $ ' + product.regularPrice;
                } else {
                    this.view.lblPrice.text = 'On Sale! $ ' + product.salePrice;
                }
                if (product.customerReviewAverage == 5) {
                    this.view.imgReview.src = 'ratings_star_5.png';
                } else if (product.customerReviewAverage >= 4) {
                    this.view.imgReview.src = 'ratings_star_4.png';
                } else if (product.customerReviewAverage >= 3) {
                    this.view.imgReview.src = 'ratings_star_3.png';
                } else if (product.customerReviewAverage >= 2) {
                    this.view.imgReview.src = 'ratings_star_2.png';
                } else if (product.customerReviewAverage >= 1) {
                    this.view.imgReview.src = 'ratings_star_1.png';
                }
                this.view.lblReview.text = product.customerReviewAverage;
                this.view.lblDescription.text = product.longDescription;
                productSKU = product.sku;
                this.view.flxProduct.setVisibility(true);
                this.getReviews();
            } else {
                alert("Product not found!");
            }
            //// }catch (err){
            //   alert("Error!");
            // }
        } else {
            alert("Error in perfoming the service call at Fabric!");
        }
    },
    getProductDetailsFailurCallback: function(error) {
        alert("getProductDetailsFailur > " + JSON.stringify(error));
    },
    getReviews: function() {
        var searchSKU = productSKU;
        if (searchSKU === ' ' || searchSKU === null) {
            this.view.lblNumberOfReviews.text = 'No Reviews';
        } else {
            //alert("searchSKU  " +JSON.stringify(searchSKU));
            var integrationServiceObject = kony.sdk.getCurrentInstance().getIntegrationService("BestBuyService");
            var headers = {};
            var input = {
                "searchSKU": searchSKU
            };
            integrationServiceObject.invokeOperation("getUserReviewForAProduct", headers, input, this.getUserReviewsSuccessCallback.bind(this), this.getUserReviewsFailurCallback.bind(this));
        }
    },
    getUserReviewsSuccessCallback: function(response) {
        if (response.opstatus === 0 && response !== null) {
            //try {    
            var reviews = response.reviews;
            //alert("name > "+JSON.stringify(reviews[0].name));
            if (reviews !== null && reviews.length > 0) {
                this.view.lblNumberOfReviews.text = 'Number of Reviews : ' + reviews.length;
                //this.view.segReviews.widgetDataMap= {
                //	"lblTitle":"title",
                //		"lblReviewer":"name",
                //      "lblReviewerDesc":"comment"
                //};
                //this.view.segReviews.setData(reviews);
                this.view.segReviews.removeAll();
                for (let i = 0; i <= reviews.length - 1; i++) {
                    var titleStr = reviews[i].title;
                    var nameStr = 'Submitted by :' + reviews[i].name;
                    var commentStr = reviews[i].comment;
                    var rating = reviews[i].rating;
                    var imgName = ' ';
                    if (rating == 5) {
                        imgName = 'ratings_star_5.png';
                    } else if (rating >= 4) {
                        imgName = 'ratings_star_4.png';
                    } else if (rating >= 3) {
                        imgName = 'ratings_star_3.png';
                    } else if (rating >= 2) {
                        imgName = 'ratings_star_2.png';
                    } else if (rating >= 1) {
                        imgName = 'ratings_star_1.png';
                    }
                    dataRow = {
                        lblTitle: titleStr,
                        lblReviewer: nameStr,
                        lblReviewerDesc: commentStr,
                        imgReviewerRate: imgName
                    };
                    this.view.segReviews.addDataAt(dataRow, i);
                }
                this.view.segReviews.setVisibility(true);
            } else {
                this.view.lblNumberOfReviews.text = 'No Reviews';
            }
            //// }catch (err){
            //   alert("Error!");
            // }
        } else {
            alert("Error in perfoming the service call at Fabric!");
        }
    },
    getUserReviewsFailurCallback: function(error) {
        alert("getProductDetailsFailur > " + JSON.stringify(error));
    },
    previousForm: function() {
        var navigationObject = new kony.mvc.Navigation("frmProducts");
        var navigationContext = {
            "searchTxt": searchTxt,
            "searchBy": searchBy,
            "categoryId": categoryId,
            "categoryName": categoryName,
            "alternateCategoryId": alternateCategoryId,
            "alternateCategoryName": alternateCategoryName
        };
        navigationObject.navigate(navigationContext);
    },
    searchProduct: function() {
        var navigationObject = new kony.mvc.Navigation("frmSearch");
        var navigationContext = {};
        navigationObject.navigate(navigationContext);
    },
    goHome: function() {
        var navigationObject = new kony.mvc.Navigation("frmMain");
        var navigationContext = {};
        navigationObject.navigate(navigationContext);
    },
    displayAllImgProduct: function() {
        var navigationObject = new kony.mvc.Navigation("frmImages");
        var navigationContext = {
            "images": images,
            "productName": this.view.lblProduct.text,
            "productId": productId,
            "searchTxt": searchTxt,
            "searchBy": searchBy,
            "categoryId": categoryId,
            "alternateCategoryId": alternateCategoryId,
            "categoryName": categoryName,
            "alternateCategoryName": alternateCategoryName
        };
        navigationObject.navigate(navigationContext);
    }
});
define("frmProductDetailControllerActions", {
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** onTouchStart defined for imgLogo **/
    AS_Image_c5ff0df649d1463b822647aed4fc4f73: function AS_Image_c5ff0df649d1463b822647aed4fc4f73(eventobject, x, y) {
        var self = this;
        return self.goHome.call(this);
    },
    /** onTouchStart defined for imgSearch **/
    AS_Image_b53625651cb340109d28257eb8ac378e: function AS_Image_b53625651cb340109d28257eb8ac378e(eventobject, x, y) {
        var self = this;
        return self.searchProduct.call(this);
    },
    /** onTouchStart defined for imgBack **/
    AS_Image_hf62122328d64b28a259da67e7da4f8f: function AS_Image_hf62122328d64b28a259da67e7da4f8f(eventobject, x, y) {
        var self = this;
        return self.previousForm.call(this);
    },
    /** onTouchStart defined for lblMore **/
    AS_Label_iba324df19b04ecd9fc64b16d353b9a5: function AS_Label_iba324df19b04ecd9fc64b16d353b9a5(eventobject, x, y) {
        var self = this;
        return self.displayAllImgProduct.call(this);
    },
    /** onRowClick defined for segReviews **/
    AS_Segment_a41c66dd6dfb45449dcca9a67ac409dc: function AS_Segment_a41c66dd6dfb45449dcca9a67ac409dc(eventobject, sectionNumber, rowNumber) {
        var self = this;
        return self.getReviews.call(this);
    },
    /** init defined for frmProductDetail **/
    AS_Form_a2d0867e382f4dfe8c2e52903a682527: function AS_Form_a2d0867e382f4dfe8c2e52903a682527(eventobject) {
        var self = this;
    },
    /** preShow defined for frmProductDetail **/
    AS_Form_daa6e51405cc47e7a87a7d15000cdcb3: function AS_Form_daa6e51405cc47e7a87a7d15000cdcb3(eventobject) {
        var self = this;
        return self.getProduct.call(this);
    },
    /** onDeviceBack defined for frmProductDetail **/
    AS_Form_c23600b52bab4a5c99516b8340fa80b4: function AS_Form_c23600b52bab4a5c99516b8340fa80b4(eventobject) {
        var self = this;
        return self.previousForm.call(this);
    },
    /** onDeviceBack defined for frmProductDetail **/
    AS_Form_c0fc63f5460d445b9c73e79acf5f4f3c: function AS_Form_c0fc63f5460d445b9c73e79acf5f4f3c(eventobject) {
        var self = this;
        return self.previousForm.call(this);
    }
});
define("frmProductDetailController", ["userfrmProductDetailController", "frmProductDetailControllerActions"], function() {
    var controller = require("userfrmProductDetailController");
    var controllerActions = ["frmProductDetailControllerActions"];
    return kony.visualizer.mixinControllerActions(controller, controllerActions);
});
