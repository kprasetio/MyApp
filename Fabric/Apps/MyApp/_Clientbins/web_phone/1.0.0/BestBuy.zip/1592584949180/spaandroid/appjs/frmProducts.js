define("frmProducts", function() {
    return function(controller) {
        function addWidgetsfrmProducts() {
            this.setDefaultUnit(kony.flex.DP);
            var ComHeader = new com.pras.sertificate.BasicForm.ComHeader({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "8%",
                "id": "ComHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "CopyslFbox0a5d876da8d774a",
                "top": "0dp",
                "width": "100%",
                "overrides": {
                    "ComHeader": {
                        "bottom": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared",
                        "left": "0dp",
                        "right": "viz.val_cleared",
                        "top": "0dp"
                    }
                }
            }, {
                "overrides": {}
            }, {
                "overrides": {}
            });
            ComHeader.imgBack.onDownloadComplete = controller.AS_Image_ge602884c22f4f9d82bff28884254b4f;
            ComHeader.imgBack.onTouchStart = controller.AS_Image_j8b7a5ebd9cd46ed9ead55326326da8a;
            ComHeader.imgLogo.onTouchStart = controller.AS_Image_ccf6a28d86c54c2eb61cee3f13bcd29a;
            ComHeader.imgSearch.onTouchStart = controller.AS_Image_i6cb295f8f3d43988703f3c6cee67937;
            var flxSeparator = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1dp",
                "id": "flxSeparator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "CopyslFbox0cedbc6f647b94f",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {}, {});
            flxSeparator.setDefaultUnit(kony.flex.DP);
            flxSeparator.add();
            var flxTitle = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "6%",
                "id": "flxTitle",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {}, {});
            flxTitle.setDefaultUnit(kony.flex.DP);
            var lblTitle = new kony.ui.Label({
                "centerY": "50%",
                "height": "100%",
                "id": "lblTitle",
                "isVisible": true,
                "left": "4dp",
                "skin": "CopydefLabel0e9843c3dc65443",
                "textStyle": {},
                "top": "0dp",
                "width": "98%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            flxTitle.add(lblTitle);
            var flxData = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "82%",
                "id": "flxData",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "2%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "96%"
            }, {}, {});
            flxData.setDefaultUnit(kony.flex.DP);
            var segData = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "data": [{
                    "imgProduct": "",
                    "lblOnSale": "",
                    "lblProductId": "",
                    "lblProductName": "",
                    "lblProductPrice": "",
                    "lblProductRate": ""
                }],
                "groupCells": false,
                "height": "100%",
                "id": "segData",
                "isVisible": false,
                "left": "0dp",
                "needPageIndicator": true,
                "onRowClick": controller.AS_Segment_g8f91896cac040a29b5f54e797273e8c,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowFocusSkin": "seg2Focus",
                "rowSkin": "seg2Normal",
                "rowTemplate": "flxSegMain",
                "scrollingEvents": {},
                "sectionHeaderSkin": "sliPhoneSegmentHeader",
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorRequired": false,
                "showScrollbars": false,
                "top": "0dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "CopyFlexContainer0j9d9b4390c3f49": "CopyFlexContainer0j9d9b4390c3f49",
                    "flxOnSale": "flxOnSale",
                    "flxProductRate": "flxProductRate",
                    "flxSegMain": "flxSegMain",
                    "imgProduct": "imgProduct",
                    "lblOnSale": "lblOnSale",
                    "lblProductId": "lblProductId",
                    "lblProductName": "lblProductName",
                    "lblProductPrice": "lblProductPrice",
                    "lblProductRate": "lblProductRate"
                },
                "width": "100%",
                "zIndex": 1
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxData.add(segData);
            this.add(ComHeader, flxSeparator, flxTitle, flxData);
        };
        return [{
            "addWidgets": addWidgetsfrmProducts,
            "enabledForIdleTimeout": false,
            "id": "frmProducts",
            "layoutType": kony.flex.FLOW_VERTICAL,
            "needAppMenu": false,
            "postShow": controller.AS_Form_bcc1349149224cf3a608cd99c3714d01,
            "skin": "slBgForm"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FLOW_VERTICAL,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "onDeviceBack": controller.AS_Form_a1d8d87314e049cda856187c2997144d,
            "retainScrollPosition": false
        }]
    }
});