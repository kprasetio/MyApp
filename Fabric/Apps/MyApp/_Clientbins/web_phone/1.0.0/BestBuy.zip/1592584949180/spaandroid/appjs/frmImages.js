define("frmImages", function() {
    return function(controller) {
        function addWidgetsfrmImages() {
            this.setDefaultUnit(kony.flex.DP);
            var ComHeader = new com.pras.sertificate.BasicForm.ComHeader({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "8%",
                "id": "ComHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "CopyslFbox0a5d876da8d774a",
                "top": "0dp",
                "width": "100%",
                "overrides": {
                    "ComHeader": {
                        "bottom": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared",
                        "left": "0dp",
                        "right": "viz.val_cleared",
                        "top": "0dp"
                    }
                }
            }, {
                "overrides": {}
            }, {
                "overrides": {}
            });
            ComHeader.imgBack.onTouchStart = controller.AS_Image_c47f0ec985ae4f0b920901c1afcfead2;
            var FlexContainer0e26cc046465d4d = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1dp",
                "id": "FlexContainer0e26cc046465d4d",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "CopyslFbox0c8be41ed022c46",
                "width": "100%",
                "zIndex": 1
            }, {}, {});
            FlexContainer0e26cc046465d4d.setDefaultUnit(kony.flex.DP);
            FlexContainer0e26cc046465d4d.add();
            var FlexContainer0gcf2917eab6a43 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "92%",
                "id": "FlexContainer0gcf2917eab6a43",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "100%",
                "zIndex": 1
            }, {}, {});
            FlexContainer0gcf2917eab6a43.setDefaultUnit(kony.flex.DP);
            var lblProductName = new kony.ui.Label({
                "height": "6%",
                "id": "lblProductName",
                "isVisible": true,
                "left": "2%",
                "skin": "CopydefLabel0ebeee36fb6034f",
                "text": "Label",
                "textStyle": {},
                "top": "5dp",
                "width": "96%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            var segImages = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "groupCells": false,
                "height": "92%",
                "id": "segImages",
                "isVisible": true,
                "left": "2%",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowFocusSkin": "seg2Focus",
                "rowSkin": "seg2Normal",
                "rowTemplate": "Flex0b923127cb2184e",
                "scrollingEvents": {},
                "sectionHeaderSkin": "sliPhoneSegmentHeader",
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorColor": "aaaaaa00",
                "separatorRequired": true,
                "separatorThickness": 1,
                "showScrollbars": false,
                "top": "8%",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "Flex0b923127cb2184e": "Flex0b923127cb2184e",
                    "imgProduct": "imgProduct"
                },
                "width": "96%",
                "zIndex": 1
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            FlexContainer0gcf2917eab6a43.add(lblProductName, segImages);
            this.add(ComHeader, FlexContainer0e26cc046465d4d, FlexContainer0gcf2917eab6a43);
        };
        return [{
            "addWidgets": addWidgetsfrmImages,
            "enabledForIdleTimeout": false,
            "id": "frmImages",
            "layoutType": kony.flex.FLOW_VERTICAL,
            "needAppMenu": false,
            "preShow": function(eventobject) {
                controller.AS_Form_fed44dc74ced4c2e9adbb19991b24cb1(eventobject);
            },
            "skin": "slBgForm"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FLOW_VERTICAL,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "onDeviceBack": controller.AS_Form_gc3b5353f1d74f17b7a203db72579e1a,
            "retainScrollPosition": false
        }]
    }
});