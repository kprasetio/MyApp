define("frmProductDetail", function() {
    return function(controller) {
        function addWidgetsfrmProductDetail() {
            this.setDefaultUnit(kony.flex.DP);
            var ComHeader = new com.pras.sertificate.BasicForm.ComHeader({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "8%",
                "id": "ComHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "CopyslFbox0a5d876da8d774a",
                "top": "0dp",
                "width": "100%",
                "overrides": {
                    "ComHeader": {
                        "bottom": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared",
                        "left": "0dp",
                        "right": "viz.val_cleared",
                        "top": "0dp"
                    },
                    "imgBack": {
                        "src": "ic_menu_back.png"
                    },
                    "imgLogo": {
                        "src": "bestbuy.png"
                    },
                    "imgSearch": {
                        "src": "search.png"
                    }
                }
            }, {
                "overrides": {}
            }, {
                "overrides": {}
            });
            ComHeader.imgBack.onTouchStart = controller.AS_Image_hf62122328d64b28a259da67e7da4f8f;
            ComHeader.imgLogo.onTouchStart = controller.AS_Image_c5ff0df649d1463b822647aed4fc4f73;
            ComHeader.imgSearch.onTouchStart = controller.AS_Image_b53625651cb340109d28257eb8ac378e;
            var flxSeparator = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1dp",
                "id": "flxSeparator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "CopyslFbox0a648641a0d6c42",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {}, {});
            flxSeparator.setDefaultUnit(kony.flex.DP);
            flxSeparator.add();
            var flxProduct = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "220dp",
                "id": "flxProduct",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "2.00%",
                "isModalContainer": false,
                "skin": "CopyslFbox0faae9568201d41",
                "top": "2.00%",
                "width": "96%",
                "zIndex": 1
            }, {}, {});
            flxProduct.setDefaultUnit(kony.flex.DP);
            var imgProduct = new kony.ui.Image2({
                "height": "112dp",
                "id": "imgProduct",
                "isVisible": true,
                "left": "9dp",
                "skin": "slImage",
                "src": "imagedrag.png",
                "top": "9dp",
                "width": "141dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblProduct = new kony.ui.Label({
                "height": "30%",
                "id": "lblProduct",
                "isVisible": true,
                "left": "178dp",
                "skin": "CopydefLabel0d29e65c9099342",
                "text": "Label",
                "textStyle": {},
                "top": "2%",
                "width": "53%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            var lblPrice = new kony.ui.Label({
                "id": "lblPrice",
                "isVisible": true,
                "left": "178dp",
                "skin": "CopydefLabel0i988168d166640",
                "text": "Label",
                "textStyle": {},
                "top": "73dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            var lblReview = new kony.ui.Label({
                "id": "lblReview",
                "isVisible": true,
                "left": "270dp",
                "skin": "CopydefLabel0d43bb70c50974d",
                "text": "Label",
                "textStyle": {},
                "top": "96dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            var CopylblReview0i45b6d1f1f0447 = new kony.ui.Label({
                "id": "CopylblReview0i45b6d1f1f0447",
                "isVisible": true,
                "left": "179dp",
                "skin": "CopydefLabel0cc016b3fc93340",
                "text": "Ave review:",
                "textStyle": {},
                "top": "96dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            var imgReview = new kony.ui.Image2({
                "height": "23dp",
                "id": "imgReview",
                "isVisible": true,
                "left": "179dp",
                "skin": "slImage",
                "src": "ratings_star_5.png",
                "top": "122dp",
                "width": "108dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblDescription = new kony.ui.Label({
                "height": "30%",
                "id": "lblDescription",
                "isVisible": true,
                "left": "2%",
                "skin": "CopydefLabel0bb914678870845",
                "text": "Label",
                "textStyle": {},
                "top": "143dp",
                "width": "96%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            var lblMore = new kony.ui.Label({
                "id": "lblMore",
                "isVisible": true,
                "left": "54dp",
                "onTouchStart": controller.AS_Label_iba324df19b04ecd9fc64b16d353b9a5,
                "skin": "CopydefLabel0eeabe7849ba24f",
                "text": "More...",
                "textStyle": {},
                "top": "124dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            flxProduct.add(imgProduct, lblProduct, lblPrice, lblReview, CopylblReview0i45b6d1f1f0447, imgReview, lblDescription, lblMore);
            var flxSeparator2 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1dp",
                "id": "flxSeparator2",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "2%",
                "isModalContainer": false,
                "skin": "CopyslFbox0ca8b50e051da43",
                "top": "0",
                "width": "96%",
                "zIndex": 1
            }, {}, {});
            flxSeparator2.setDefaultUnit(kony.flex.DP);
            flxSeparator2.add();
            var flxReviews = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "60%",
                "id": "flxReviews",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "2%",
                "isModalContainer": false,
                "skin": "CopyslFbox0i120d799b0504e",
                "top": "0dp",
                "width": "96%",
                "zIndex": 1
            }, {}, {});
            flxReviews.setDefaultUnit(kony.flex.DP);
            var FlexContainer0baed68fc3b4143 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "98%",
                "id": "FlexContainer0baed68fc3b4143",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "1%",
                "isModalContainer": false,
                "skin": "CopyslFbox0aba59b98fa5f4d",
                "top": "1%",
                "width": "97%",
                "zIndex": 1
            }, {}, {});
            FlexContainer0baed68fc3b4143.setDefaultUnit(kony.flex.DP);
            var FlexContainer0d704f9a816c744 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "8%",
                "id": "FlexContainer0d704f9a816c744",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "CopyslFbox0e763543ae74340",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {}, {});
            FlexContainer0d704f9a816c744.setDefaultUnit(kony.flex.DP);
            var lblNumberOfReviews = new kony.ui.Label({
                "id": "lblNumberOfReviews",
                "isVisible": true,
                "left": "4dp",
                "skin": "CopydefLabel0f268d398c76942",
                "text": "Number of Reviews:",
                "textStyle": {},
                "top": "6dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            FlexContainer0d704f9a816c744.add(lblNumberOfReviews);
            var segReviews = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "data": [{
                    "imgReviewerRate": "",
                    "lblReviewer": "",
                    "lblReviewerDesc": "",
                    "lblTitle": ""
                }],
                "groupCells": false,
                "height": "87%",
                "id": "segReviews",
                "isVisible": false,
                "left": "2%",
                "needPageIndicator": true,
                "onRowClick": controller.AS_Segment_a41c66dd6dfb45449dcca9a67ac409dc,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowFocusSkin": "seg2Focus",
                "rowSkin": "Copyseg0eee9a3a50d0745",
                "rowTemplate": "CopyflxItems0ee78966fdbcd43",
                "scrollingEvents": {},
                "sectionHeaderSkin": "sliPhoneSegmentHeader",
                "selectionBehavior": constants.SEGUI_SINGLE_SELECT_BEHAVIOR,
                "separatorRequired": false,
                "showScrollbars": true,
                "top": "2%",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "CopyflxItems0ee78966fdbcd43": "CopyflxItems0ee78966fdbcd43",
                    "imgReviewerRate": "imgReviewerRate",
                    "lblReviewer": "lblReviewer",
                    "lblReviewerDesc": "lblReviewerDesc",
                    "lblTitle": "lblTitle"
                },
                "width": "96%",
                "zIndex": 1
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            FlexContainer0baed68fc3b4143.add(FlexContainer0d704f9a816c744, segReviews);
            flxReviews.add(FlexContainer0baed68fc3b4143);
            this.add(ComHeader, flxSeparator, flxProduct, flxSeparator2, flxReviews);
        };
        return [{
            "addWidgets": addWidgetsfrmProductDetail,
            "enabledForIdleTimeout": false,
            "id": "frmProductDetail",
            "init": controller.AS_Form_a2d0867e382f4dfe8c2e52903a682527,
            "layoutType": kony.flex.FLOW_VERTICAL,
            "needAppMenu": false,
            "preShow": function(eventobject) {
                controller.AS_Form_daa6e51405cc47e7a87a7d15000cdcb3(eventobject);
            },
            "skin": "slBgForm"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FLOW_VERTICAL,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "onDeviceBack": controller.AS_Form_c0fc63f5460d445b9c73e79acf5f4f3c,
            "retainScrollPosition": false
        }]
    }
});