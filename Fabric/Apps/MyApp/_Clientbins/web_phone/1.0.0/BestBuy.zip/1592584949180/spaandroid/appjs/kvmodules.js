define('applicationController',{
    appInit: function(params) {
        skinsInit();
        kony.mvc.registry.add("com.pras.sertificate.BasicForm.ComHeader", "ComHeader", "ComHeaderController");
        kony.application.registerMaster({
            "namespace": "com.pras.sertificate.BasicForm",
            "classname": "ComHeader",
            "name": "com.pras.sertificate.BasicForm.ComHeader"
        });
        kony.mvc.registry.add("CopyflxSeg", "CopyflxSeg", "CopyflxSegController");
        kony.mvc.registry.add("flxSampleRowTemplate", "flxSampleRowTemplate", "flxSampleRowTemplateController");
        kony.mvc.registry.add("flxSectionHeaderTemplate", "flxSectionHeaderTemplate", "flxSectionHeaderTemplateController");
        kony.mvc.registry.add("CopyflxSeg1", "CopyflxSeg1", "CopyflxSeg1Controller");
        kony.mvc.registry.add("Flex0b923127cb2184e", "Flex0b923127cb2184e", "Flex0b923127cb2184eController");
        kony.mvc.registry.add("flxItems", "flxItems", "flxItemsController");
        kony.mvc.registry.add("flxSegMain", "flxSegMain", "flxSegMainController");
        kony.mvc.registry.add("CopyflxItems0ee78966fdbcd43", "CopyflxItems0ee78966fdbcd43", "CopyflxItems0ee78966fdbcd43Controller");
        kony.mvc.registry.add("frmImages", "frmImages", "frmImagesController");
        kony.mvc.registry.add("frmMain", "frmMain", "frmMainController");
        kony.mvc.registry.add("frmProductDetail", "frmProductDetail", "frmProductDetailController");
        kony.mvc.registry.add("frmProducts", "frmProducts", "frmProductsController");
        setAppBehaviors();
    },
    postAppInitCallBack: function(eventObj) {},
    appmenuseq: function() {
        new kony.mvc.Navigation("frmMain").navigate();
    }
});

define("com/pras/sertificate/BasicForm/ComHeader/userComHeaderController", [],function() {
    return {};
});
define("com/pras/sertificate/BasicForm/ComHeader/ComHeaderControllerActions", {
    /*
          This is an auto generated file and any modifications to it may result in corruption of the action sequence.
        */
});
define("com/pras/sertificate/BasicForm/ComHeader/ComHeaderController", ["com/pras/sertificate/BasicForm/ComHeader/userComHeaderController", "com/pras/sertificate/BasicForm/ComHeader/ComHeaderControllerActions"], function() {
    var controller = require("com/pras/sertificate/BasicForm/ComHeader/userComHeaderController");
    var actions = require("com/pras/sertificate/BasicForm/ComHeader/ComHeaderControllerActions");
    for (var key in actions) {
        controller[key] = actions[key];
    }
    return controller;
});

define('com/pras/sertificate/BasicForm/ComHeader/ComHeader',[],function() {
    return function(controller) {
        var ComHeader = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "isMaster": true,
            "height": "8%",
            "id": "ComHeader",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "CopyslFbox0a5d876da8d774a",
            "top": "0dp",
            "width": "100%"
        }, controller.args[0], "ComHeader"), extendConfig({}, controller.args[1], "ComHeader"), extendConfig({}, controller.args[2], "ComHeader"));
        ComHeader.setDefaultUnit(kony.flex.DP);
        var imgLogo = new kony.ui.Image2(extendConfig({
            "centerX": "50.00%",
            "centerY": "50.00%",
            "height": "50dp",
            "id": "imgLogo",
            "isVisible": true,
            "skin": "slImage",
            "src": "bestbuy.png",
            "width": "57dp",
            "zIndex": 1
        }, controller.args[0], "imgLogo"), extendConfig({
            "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "imgLogo"), extendConfig({}, controller.args[2], "imgLogo"));
        var imgSearch = new kony.ui.Image2(extendConfig({
            "centerY": "50.00%",
            "height": "37dp",
            "id": "imgSearch",
            "isVisible": true,
            "left": "87.03%",
            "skin": "slImage",
            "src": "search.png",
            "top": 0,
            "width": "43dp",
            "zIndex": 1
        }, controller.args[0], "imgSearch"), extendConfig({
            "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "imgSearch"), extendConfig({}, controller.args[2], "imgSearch"));
        var imgBack = new kony.ui.Image2(extendConfig({
            "centerY": "50%",
            "height": "37dp",
            "id": "imgBack",
            "isVisible": true,
            "left": "2%",
            "skin": "slImage",
            "src": "ic_menu_back.png",
            "top": 0,
            "width": "43dp",
            "zIndex": 1
        }, controller.args[0], "imgBack"), extendConfig({
            "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "imgBack"), extendConfig({}, controller.args[2], "imgBack"));
        ComHeader.add(imgLogo, imgSearch, imgBack);
        return ComHeader;
    }
})
;
define("CopyflxSeg", [],function() {
    return function(controller) {
        var CopyflxSeg = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "45%",
            "id": "CopyflxSeg",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "isModalContainer": false,
            "skin": "konympCLsknFlxSeg"
        }, {}, {});
        CopyflxSeg.setDefaultUnit(kony.flex.DP);
        var lblModel = new kony.ui.Label({
            "height": "6%",
            "id": "lblModel",
            "isVisible": true,
            "left": "4%",
            "skin": "konympCLsknMainModel",
            "text": "2016 Audi S3",
            "top": "5%",
            "width": "26%",
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "renderAsAnchor": false,
            "textCopyable": false
        });
        var lblPrice = new kony.ui.Label({
            "id": "lblPrice",
            "isVisible": true,
            "left": "4%",
            "skin": "konympCLsknLblModelValue",
            "text": "Price:",
            "top": "15%",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "renderAsAnchor": false,
            "textCopyable": false
        });
        var lblPriceValue = new kony.ui.Label({
            "id": "lblPriceValue",
            "isVisible": true,
            "left": "14%",
            "skin": "konympCLsknLblModel",
            "text": " $28,000",
            "top": "14%",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "renderAsAnchor": false,
            "textCopyable": false
        });
        var lblMileage = new kony.ui.Label({
            "id": "lblMileage",
            "isVisible": true,
            "left": "58%",
            "skin": "konympCLsknLblModelValue",
            "text": "Mileage:",
            "top": "15%",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "renderAsAnchor": false,
            "textCopyable": false
        });
        var lblMileageValue = new kony.ui.Label({
            "id": "lblMileageValue",
            "isVisible": true,
            "left": "73%",
            "skin": "konympCLsknLblModel",
            "text": " 16854 Mi",
            "top": "14%",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "renderAsAnchor": false,
            "textCopyable": false
        });
        var flxImg = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "55%",
            "id": "flxImg",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "4%",
            "isModalContainer": false,
            "top": "24%",
            "width": "90%",
            "zIndex": 1
        }, {}, {});
        flxImg.setDefaultUnit(kony.flex.DP);
        var imgCar = new kony.ui.Image2({
            "id": "imgCar",
            "isVisible": true,
            "left": "0dp",
            "skin": "CopyCopyslImage3",
            "src": "konymp_cl_car_list_image_1.png",
            "top": "0dp",
            "width": "100%",
            "zIndex": 1
        }, {
            "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {});
        flxImg.add(imgCar);
        var flxDetails = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "14%",
            "id": "flxDetails",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "4%",
            "isModalContainer": false,
            "top": "81%",
            "width": "90%",
            "zIndex": 1
        }, {}, {});
        flxDetails.setDefaultUnit(kony.flex.DP);
        var lblEngine = new kony.ui.Label({
            "id": "lblEngine",
            "isVisible": true,
            "left": "0%",
            "skin": "konympCLsknLblDesign",
            "text": "Engine:",
            "top": "0%",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "renderAsAnchor": false,
            "textCopyable": false
        });
        var lblEngineValue = new kony.ui.Label({
            "id": "lblEngineValue",
            "isVisible": true,
            "left": "14%",
            "skin": "konympCLsknLblDesignValue",
            "text": "3.0L,",
            "top": "0%",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "renderAsAnchor": false,
            "textCopyable": false
        });
        var Transmission = new kony.ui.Label({
            "id": "Transmission",
            "isVisible": true,
            "left": "23%",
            "skin": "konympCLsknLblDesign",
            "text": "Transmission:",
            "top": "0%",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "renderAsAnchor": false,
            "textCopyable": false
        });
        var lblTransmissionValue = new kony.ui.Label({
            "id": "lblTransmissionValue",
            "isVisible": true,
            "left": "49%",
            "skin": "konympCLsknLblDesignValue",
            "text": "Automatic,",
            "top": "0%",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "renderAsAnchor": false,
            "textCopyable": false
        });
        var lblColor = new kony.ui.Label({
            "id": "lblColor",
            "isVisible": true,
            "left": "69%",
            "skin": "konympCLsknLblDesign",
            "text": "External Color:",
            "top": "0%",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "renderAsAnchor": false,
            "textCopyable": false
        });
        var lblColorValue = new kony.ui.Label({
            "id": "lblColorValue",
            "isVisible": true,
            "left": "0%",
            "skin": "konympCLsknLblDesignValue",
            "text": "Blue,",
            "top": "53%",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "renderAsAnchor": false,
            "textCopyable": false
        });
        var lblInterior = new kony.ui.Label({
            "id": "lblInterior",
            "isVisible": true,
            "left": "9%",
            "skin": "konympCLsknLblDesign",
            "text": "Interior Color:",
            "top": "53%",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "renderAsAnchor": false,
            "textCopyable": false
        });
        var lblInteriorValue = new kony.ui.Label({
            "id": "lblInteriorValue",
            "isVisible": true,
            "left": "34%",
            "skin": "konympCLsknLblDesignValue",
            "text": "Black",
            "top": "53%",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "renderAsAnchor": false,
            "textCopyable": false
        });
        flxDetails.add(lblEngine, lblEngineValue, Transmission, lblTransmissionValue, lblColor, lblColorValue, lblInterior, lblInteriorValue);
        CopyflxSeg.add(lblModel, lblPrice, lblPriceValue, lblMileage, lblMileageValue, flxImg, flxDetails);
        return CopyflxSeg;
    }
})
;
define("flxSampleRowTemplate", [],function() {
    return function(controller) {
        var flxSampleRowTemplate = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "75dp",
            "id": "flxSampleRowTemplate",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "isModalContainer": false,
            "skin": "sknSampleRowTemplate"
        }, {}, {});
        flxSampleRowTemplate.setDefaultUnit(kony.flex.DP);
        var lblHeading = new kony.ui.Label({
            "id": "lblHeading",
            "isVisible": true,
            "left": "4%",
            "maxWidth": "50%",
            "skin": "sknLblRowHeading",
            "text": "Heading",
            "textStyle": {},
            "top": "8.00%",
            "width": "45%",
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "renderAsAnchor": false,
            "textCopyable": false
        });
        var lblDescription = new kony.ui.Label({
            "bottom": "10%",
            "id": "lblDescription",
            "isVisible": true,
            "left": "4%",
            "maxNumberOfLines": 3,
            "maxWidth": "70%",
            "skin": "sknLblDescription",
            "text": "Sub-Heading",
            "textStyle": {},
            "textTruncatePosition": constants.TEXT_TRUNCATE_NONE,
            "top": "42%",
            "width": "70%",
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "renderAsAnchor": false,
            "textCopyable": false
        });
        var lblTime = new kony.ui.Label({
            "id": "lblTime",
            "isVisible": true,
            "right": "9%",
            "skin": "sknLblTimeStamp",
            "text": "Timestamp",
            "textStyle": {},
            "top": "10%",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "renderAsAnchor": false,
            "textCopyable": false
        });
        var lblStrip = new kony.ui.Label({
            "height": "100%",
            "id": "lblStrip",
            "isVisible": true,
            "left": "0dp",
            "maxWidth": "1%",
            "skin": "sknLblStrip",
            "textStyle": {},
            "top": "0dp",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "renderAsAnchor": false,
            "textCopyable": false
        });
        flxSampleRowTemplate.add(lblHeading, lblDescription, lblTime, lblStrip);
        return flxSampleRowTemplate;
    }
})
;
define("flxSectionHeaderTemplate", [],function() {
    return function(controller) {
        var flxSectionHeaderTemplate = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "45dp",
            "id": "flxSectionHeaderTemplate",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "isModalContainer": false,
            "skin": "sknSampleSectionHeaderTemplate"
        }, {}, {});
        flxSectionHeaderTemplate.setDefaultUnit(kony.flex.DP);
        var lblHeading = new kony.ui.Label({
            "centerY": "50%",
            "id": "lblHeading",
            "isVisible": true,
            "left": "4%",
            "maxWidth": "50%",
            "skin": "sknSectionHeaderLabelSkin",
            "text": "Heading",
            "textStyle": {},
            "width": "75%",
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "renderAsAnchor": false,
            "textCopyable": false
        });
        flxSectionHeaderTemplate.add(lblHeading);
        return flxSectionHeaderTemplate;
    }
})
;
define("CopyflxSeg1", [],function() {
    return function(controller) {
        var CopyflxSeg1 = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "33.30%",
            "id": "CopyflxSeg1",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "isModalContainer": false,
            "skin": "CopyslFbox0g4cba210b0ab4a"
        }, {}, {});
        CopyflxSeg1.setDefaultUnit(kony.flex.DP);
        var imgRow = new kony.ui.Image2({
            "height": "100%",
            "id": "imgRow",
            "isVisible": true,
            "left": "0dp",
            "skin": "CopyCopyslImage4",
            "src": "konymp_rl_retail_image_1.png",
            "top": "0dp",
            "width": "100%",
            "zIndex": 1
        }, {
            "imageScaleMode": constants.IMAGE_SCALE_MODE_FIT_TO_DIMENSIONS,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {});
        var flxFav = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "13%",
            "id": "flxFav",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "isModalContainer": false,
            "right": "3.50%",
            "top": "2%",
            "width": "8%",
            "zIndex": 1
        }, {}, {});
        flxFav.setDefaultUnit(kony.flex.DP);
        var imgFav = new kony.ui.Image2({
            "height": "100%",
            "id": "imgFav",
            "isVisible": true,
            "left": "0dp",
            "skin": "CopyCopyslImage4",
            "src": "konymp_rlfavorite_normal.png",
            "top": "0dp",
            "width": "100%",
            "zIndex": 1
        }, {
            "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {});
        flxFav.add(imgFav);
        var lblDetail = new kony.ui.Label({
            "id": "lblDetail",
            "isVisible": true,
            "left": "4%",
            "skin": "CopyslLabel0d9a195cbc6bc4e",
            "text": "4 bds, 5 ba, 1452 sqft",
            "top": "78%",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 2
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "renderAsAnchor": false,
            "textCopyable": false
        });
        var lblDescription = new kony.ui.Label({
            "bottom": "3.50%",
            "id": "lblDescription",
            "isVisible": true,
            "left": "4%",
            "skin": "konympRLsknLblDescription",
            "text": "877 Rutherford Drive Apt. 109",
            "top": "88%",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 2
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "renderAsAnchor": false,
            "textCopyable": false
        });
        var lblCost = new kony.ui.Label({
            "bottom": "3.50%",
            "id": "lblCost",
            "isVisible": true,
            "right": "5%",
            "skin": "CopyslLabel0i5fbf567b5774c",
            "text": "$33,104",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 2
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "renderAsAnchor": false,
            "textCopyable": false
        });
        var flxShadow = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "bottom": "0%",
            "clipBounds": true,
            "id": "flxShadow",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0%",
            "isModalContainer": false,
            "skin": "konympRLsknFlxShadow",
            "width": "100%",
            "zIndex": 1
        }, {}, {});
        flxShadow.setDefaultUnit(kony.flex.DP);
        flxShadow.add();
        CopyflxSeg1.add(imgRow, flxFav, lblDetail, lblDescription, lblCost, flxShadow);
        return CopyflxSeg1;
    }
})
;
define("Flex0b923127cb2184e", [],function() {
    return function(controller) {
        var Flex0b923127cb2184e = new kony.ui.FlexContainer({
            "clipBounds": true,
            "height": "220dp",
            "id": "Flex0b923127cb2184e",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "CopyslFbox0ddce0481ed534e",
            "top": "0dp",
            "width": "100%"
        }, {}, {});
        Flex0b923127cb2184e.setDefaultUnit(kony.flex.DP);
        var imgProduct = new kony.ui.Image2({
            "centerX": "50%",
            "centerY": "50%",
            "height": "193dp",
            "id": "imgProduct",
            "isVisible": true,
            "left": 0,
            "skin": "slImage",
            "src": "imagedrag.png",
            "top": 0,
            "width": "307dp",
            "zIndex": 1,
            "blur": {
                "enabled": false,
                "value": 0
            }
        }, {
            "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {});
        Flex0b923127cb2184e.add(imgProduct);
        return Flex0b923127cb2184e;
    }
})
;
define("flxItems", [],function() {
    return function(controller) {
        var flxItems = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "8%",
            "id": "flxItems",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "flxSegRow",
            "top": "0dp",
            "width": "100%"
        }, {}, {});
        flxItems.setDefaultUnit(kony.flex.DP);
        var lblCategory = new kony.ui.Label({
            "centerX": "50%",
            "centerY": "50%",
            "id": "lblCategory",
            "isVisible": true,
            "left": "2%",
            "skin": "sknLblBlack",
            "text": "Category",
            "textStyle": {},
            "top": "0dp",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "renderAsAnchor": false,
            "textCopyable": false
        });
        var lblCategoryId = new kony.ui.Label({
            "id": "lblCategoryId",
            "isVisible": false,
            "left": "141dp",
            "skin": "defLabel",
            "text": "Label",
            "textStyle": {},
            "top": "11dp",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "renderAsAnchor": false,
            "textCopyable": false
        });
        flxItems.add(lblCategory, lblCategoryId);
        return flxItems;
    }
})
;
define("flxSegMain", [],function() {
    return function(controller) {
        var flxSegMain = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
            "clipBounds": true,
            "id": "flxSegMain",
            "isVisible": true,
            "layoutType": kony.flex.FLOW_VERTICAL,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "flxSegRow",
            "top": "0dp",
            "width": "100%"
        }, {}, {});
        flxSegMain.setDefaultUnit(kony.flex.DP);
        var flxOnSale = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
            "clipBounds": true,
            "id": "flxOnSale",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "CopyslFbox0a4af5453e94c42",
            "top": "0dp",
            "width": "100%",
            "zIndex": 1
        }, {}, {});
        flxOnSale.setDefaultUnit(kony.flex.DP);
        var lblOnSale = new kony.ui.Label({
            "centerX": "50%",
            "id": "lblOnSale",
            "isVisible": true,
            "skin": "CopydefLabel0c397e543b68842",
            "text": "!!!ON SALE!!!",
            "textStyle": {},
            "top": 0,
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "renderAsAnchor": false,
            "textCopyable": false
        });
        flxOnSale.add(lblOnSale);
        var CopyFlexContainer0j9d9b4390c3f49 = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
            "clipBounds": true,
            "id": "CopyFlexContainer0j9d9b4390c3f49",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "0dp",
            "width": "100%",
            "zIndex": 1
        }, {}, {});
        CopyFlexContainer0j9d9b4390c3f49.setDefaultUnit(kony.flex.DP);
        var lblProductName = new kony.ui.Label({
            "height": "50dp",
            "id": "lblProductName",
            "isVisible": true,
            "left": "39.67%",
            "skin": "sknLblBlack",
            "text": "Nama",
            "textStyle": {},
            "top": "7dp",
            "width": "57%",
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "renderAsAnchor": false,
            "textCopyable": false
        });
        var lblProductPrice = new kony.ui.Label({
            "id": "lblProductPrice",
            "isVisible": true,
            "left": "39.63%",
            "skin": "sknLblRed",
            "text": "0",
            "textStyle": {},
            "top": "56dp",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "renderAsAnchor": false,
            "textCopyable": false
        });
        var imgProduct = new kony.ui.Image2({
            "height": "73dp",
            "id": "imgProduct",
            "isVisible": true,
            "left": "8dp",
            "skin": "slImage",
            "src": "imagedrag.png",
            "top": "8dp",
            "width": "135dp",
            "zIndex": 1
        }, {
            "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {});
        var lblProductId = new kony.ui.Label({
            "id": "lblProductId",
            "isVisible": false,
            "left": "245dp",
            "skin": "defLabel",
            "text": "Label",
            "textStyle": {},
            "top": "50dp",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "renderAsAnchor": false,
            "textCopyable": false
        });
        CopyFlexContainer0j9d9b4390c3f49.add(lblProductName, lblProductPrice, imgProduct, lblProductId);
        var flxProductRate = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
            "clipBounds": true,
            "id": "flxProductRate",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "CopyslFbox0gd616cfb30584f",
            "top": "0dp",
            "width": "100%",
            "zIndex": 1
        }, {}, {});
        flxProductRate.setDefaultUnit(kony.flex.DP);
        var lblProductRate = new kony.ui.Label({
            "id": "lblProductRate",
            "isVisible": true,
            "left": "39.54%",
            "skin": "sknLblBlack",
            "text": "0",
            "textStyle": {},
            "top": "-3dp",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "renderAsAnchor": false,
            "textCopyable": false
        });
        flxProductRate.add(lblProductRate);
        flxSegMain.add(flxOnSale, CopyFlexContainer0j9d9b4390c3f49, flxProductRate);
        return flxSegMain;
    }
})
;
define("CopyflxItems0ee78966fdbcd43", [],function() {
    return function(controller) {
        var CopyflxItems0ee78966fdbcd43 = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "50%",
            "id": "CopyflxItems0ee78966fdbcd43",
            "isVisible": true,
            "layoutType": kony.flex.FLOW_VERTICAL,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "flxSegRow",
            "top": "0dp",
            "width": "100%"
        }, {}, {});
        CopyflxItems0ee78966fdbcd43.setDefaultUnit(kony.flex.DP);
        var lblTitle = new kony.ui.Label({
            "id": "lblTitle",
            "isVisible": true,
            "left": "10dp",
            "skin": "CopydefLabel0i874ad6686544c",
            "text": "Label",
            "textStyle": {},
            "top": "9dp",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "renderAsAnchor": false,
            "textCopyable": false
        });
        var lblReviewer = new kony.ui.Label({
            "id": "lblReviewer",
            "isVisible": true,
            "left": "10dp",
            "skin": "CopydefLabel0g5ab41bdeb6140",
            "text": "Label",
            "textStyle": {},
            "top": "2dp",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "renderAsAnchor": false,
            "textCopyable": false
        });
        var imgReviewerRate = new kony.ui.Image2({
            "height": "23dp",
            "id": "imgReviewerRate",
            "isVisible": true,
            "left": "9dp",
            "skin": "slImage",
            "src": "ratings_star_5.png",
            "top": "6dp",
            "width": "104dp",
            "zIndex": 1
        }, {
            "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {});
        var lblReviewerDesc = new kony.ui.Label({
            "height": "70%",
            "id": "lblReviewerDesc",
            "isVisible": true,
            "left": "11dp",
            "skin": "CopydefLabel0cec9a2f5edbc4b",
            "text": "Label",
            "textStyle": {},
            "top": "6dp",
            "width": "94%",
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "renderAsAnchor": false,
            "textCopyable": false
        });
        CopyflxItems0ee78966fdbcd43.add(lblTitle, lblReviewer, imgReviewerRate, lblReviewerDesc);
        return CopyflxItems0ee78966fdbcd43;
    }
})
;
define("userCopyflxSegController", {
    //Type your controller code here 
});
define("CopyflxSegControllerActions", {
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
});
define("CopyflxSegController", ["userCopyflxSegController", "CopyflxSegControllerActions"], function() {
    var controller = require("userCopyflxSegController");
    var controllerActions = ["CopyflxSegControllerActions"];
    return kony.visualizer.mixinControllerActions(controller, controllerActions);
});

define("userflxSampleRowTemplateController", {
    //Type your controller code here 
});
define("flxSampleRowTemplateControllerActions", {
    /* 
    This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
});
define("flxSampleRowTemplateController", ["userflxSampleRowTemplateController", "flxSampleRowTemplateControllerActions"], function() {
    var controller = require("userflxSampleRowTemplateController");
    var controllerActions = ["flxSampleRowTemplateControllerActions"];
    return kony.visualizer.mixinControllerActions(controller, controllerActions);
});

define("userflxSectionHeaderTemplateController", {
    //Type your controller code here 
});
define("flxSectionHeaderTemplateControllerActions", {
    /* 
    This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
});
define("flxSectionHeaderTemplateController", ["userflxSectionHeaderTemplateController", "flxSectionHeaderTemplateControllerActions"], function() {
    var controller = require("userflxSectionHeaderTemplateController");
    var controllerActions = ["flxSectionHeaderTemplateControllerActions"];
    return kony.visualizer.mixinControllerActions(controller, controllerActions);
});

define("userCopyflxSeg1Controller", {
    //Type your controller code here 
});
define("CopyflxSeg1ControllerActions", {
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
});
define("CopyflxSeg1Controller", ["userCopyflxSeg1Controller", "CopyflxSeg1ControllerActions"], function() {
    var controller = require("userCopyflxSeg1Controller");
    var controllerActions = ["CopyflxSeg1ControllerActions"];
    return kony.visualizer.mixinControllerActions(controller, controllerActions);
});

define("userFlex0b923127cb2184eController", {
    //Type your controller code here 
});
define("Flex0b923127cb2184eControllerActions", {
    /* 
    This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
});
define("Flex0b923127cb2184eController", ["userFlex0b923127cb2184eController", "Flex0b923127cb2184eControllerActions"], function() {
    var controller = require("userFlex0b923127cb2184eController");
    var controllerActions = ["Flex0b923127cb2184eControllerActions"];
    return kony.visualizer.mixinControllerActions(controller, controllerActions);
});

define("userflxItemsController", {
    //Type your controller code here 
});
define("flxItemsControllerActions", {
    /* 
    This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
});
define("flxItemsController", ["userflxItemsController", "flxItemsControllerActions"], function() {
    var controller = require("userflxItemsController");
    var controllerActions = ["flxItemsControllerActions"];
    return kony.visualizer.mixinControllerActions(controller, controllerActions);
});

define("userflxSegMainController", {
    //Type your controller code here 
});
define("flxSegMainControllerActions", {
    //Type your controller code here 
});
define("flxSegMainController", ["userflxSegMainController", "flxSegMainControllerActions"], function() {
    var controller = require("userflxSegMainController");
    var controllerActions = ["flxSegMainControllerActions"];
    return kony.visualizer.mixinControllerActions(controller, controllerActions);
});

define("userCopyflxItems0ee78966fdbcd43Controller", {
    //Type your controller code here 
});
define("CopyflxItems0ee78966fdbcd43ControllerActions", {
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** onTouchStart defined for lblReviewerDesc **/
    AS_Label_cc31b66e0b8940b29d6a1876b423fd63: function AS_Label_cc31b66e0b8940b29d6a1876b423fd63(eventobject, x, y, context) {
        var self = this;
    }
});
define("CopyflxItems0ee78966fdbcd43Controller", ["userCopyflxItems0ee78966fdbcd43Controller", "CopyflxItems0ee78966fdbcd43ControllerActions"], function() {
    var controller = require("userCopyflxItems0ee78966fdbcd43Controller");
    var controllerActions = ["CopyflxItems0ee78966fdbcd43ControllerActions"];
    return kony.visualizer.mixinControllerActions(controller, controllerActions);
});

require(['applicationController','com/pras/sertificate/BasicForm/ComHeader/ComHeaderController','com/pras/sertificate/BasicForm/ComHeader/ComHeader','CopyflxSeg','flxSampleRowTemplate','flxSectionHeaderTemplate','CopyflxSeg1','Flex0b923127cb2184e','flxItems','flxSegMain','CopyflxItems0ee78966fdbcd43','CopyflxSegController','flxSampleRowTemplateController','flxSectionHeaderTemplateController','CopyflxSeg1Controller','Flex0b923127cb2184eController','flxItemsController','flxSegMainController','CopyflxItems0ee78966fdbcd43Controller'], function(){});

define("sparequirefileslist", function(){});

