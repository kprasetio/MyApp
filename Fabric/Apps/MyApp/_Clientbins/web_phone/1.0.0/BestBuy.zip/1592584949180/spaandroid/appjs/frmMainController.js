var categoryId = ' ';
var categoryName;
var path;
define("userfrmMainController", {
    //Type your controller code here 
    getCategories: function() {
        this.view.flxSearch.setVisibility(false);
        this.view.segData.setVisibility(false);
        if (categoryId === ' ' || categoryId === null) {
            categoryId = 'cat00000';
        }
        var integrationServiceObject = kony.sdk.getCurrentInstance().getIntegrationService("BestBuyService");
        var headers = {};
        var input = {
            "categoryId": categoryId
        };
        integrationServiceObject.invokeOperation("getCategories", headers, input, this.getCategoriesSuccessCallback.bind(this), this.getCategoriesFailurCallback.bind(this));
    },
    getCategoriesSuccessCallback: function(response) {
        if (response.opstatus === 0 && response !== null) {
            path = response.path;
            var subCategories = response.subCategories;
            if (path !== undefined || subCategories !== undefined) {
                for (let i = 0; i <= path.length - 1; i++) {
                    if (i === 0) {
                        this.view.lblPath.text = 'Home';
                    } else {
                        this.view.lblPath.text += '>' + path[i].pathName;
                        categoryId = path[i].pathId;
                    }
                }
                if ((path.length - 1) === 0) {
                    this.view.ComHeader.imgBack.setVisibility(false);
                } else {
                    this.view.ComHeader.imgBack.setVisibility(true);
                }
                if (subCategories !== null && subCategories.length > 0) {
                    this.view.segData.widgetDataMap = {
                        "lblCategory": "categoryName",
                        "lblCategoryId": "categoryId"
                    };
                    this.view.segData.setData(subCategories);
                    this.view.segData.setVisibility(true);
                } else {
                    var navigationObject = new kony.mvc.Navigation("frmProducts");
                    var alternateCategoryId = path[(path.length - 2)].pathId;
                    var alternateCategoryName = path[(path.length - 2)].pathName;
                    var navigationContext = {
                        "categoryId": categoryId,
                        "categoryName": categoryName,
                        "alternateCategoryId": alternateCategoryId,
                        "alternateCategoryName": alternateCategoryName,
                        "searchBy": "CATEGORYID"
                    };
                    navigationObject.navigate(navigationContext);
                }
            } else {
                alert("Error getting data for " + categoryName);
            }
        } else {
            alert("Error in perfoming the service call at Fabric!");
        }
    },
    getCategoriesFailurCallback: function(error) {
        alert("getCategoriesFailur > " + JSON.stringify(error));
    },
    showDetailsOfSelectedRow: function() {
        var selectRowItems = this.view.segData.selectedRowItems;
        categoryId = selectRowItems[0].categoryId;
        categoryName = selectRowItems[0].categoryName;
        this.getCategories();
    },
    previousForm: function() {
        if (path !== null) {
            if ((path.length - 1) === 0) {
                kony.application.exit();
            } else {
                categoryId = path[path.length - 2].pathId;
                this.getCategories();
            }
        } else {
            categoryId = ' ';
            this.getCategories();
        }
    },
    searchProduct: function() {
        this.view.txtSearch.text = "";
        this.view.flxSearch.setVisibility(true);
        this.view.segData.setEnabled(false);
        //this.view.segData.rowSkin="seg2Disable";
        this.view.flxSearch.animate(kony.ui.createAnimation({
            "0": {
                "stepConfig": {
                    "timingFunction": kony.anim.EASE
                },
                "opacity": 0
            },
            "100": {
                "stepConfig": {
                    "timingFunction": kony.anim.EASE
                },
                "opacity": 1
            }
        }), {
            "delay": 0,
            "iterationCount": 1,
            "fillMode": kony.anim.FILL_MODE_FORWARDS,
            "duration": 1,
            "direction": kony.anim.DIRECTION_ALTERNATE
        }, {
            "animationEnd": this.animateSearch
        });
        //COBADISINI
        this.view.segData.animate(kony.ui.createAnimation({
            "100": {
                "stepConfig": {
                    "timingFunction": kony.anim.EASE
                },
                "opacity": 0.3
            }
        }), {
            "delay": 0,
            "iterationCount": 1,
            "fillMode": kony.anim.FILL_MODE_FORWARDS,
            "duration": 0.25
        }, {
            // "animationEnd": STYLE_ACTION____dbd2e4289ee444f48896a916e58bd9b4_Callback
        });
    },
    cancelSearch: function() {
        this.view.flxSearch.animate(kony.ui.createAnimation({
            "100": {
                "stepConfig": {
                    "timingFunction": kony.anim.EASE
                },
                "top": "0dp"
            }
        }), {
            "delay": 0,
            "iterationCount": 1,
            "fillMode": kony.anim.FILL_MODE_FORWARDS,
            "duration": 0.25,
            "direction": kony.anim.DIRECTION_ALTERNATE
        }, {
            "animationEnd": this.animationOpacity0
        });
        this.view.flxMain.animate(kony.ui.createAnimation({
            "100": {
                "stepConfig": {
                    "timingFunction": kony.anim.EASE
                },
                "top": "8%"
            }
        }), {
            "delay": 0,
            "iterationCount": 1,
            "fillMode": kony.anim.FILL_MODE_FORWARDS,
            "duration": 0.25,
            "direction": kony.anim.DIRECTION_ALTERNATE
        }, {});
        this.view.segData.animate(kony.ui.createAnimation({
            "100": {
                "stepConfig": {
                    "timingFunction": kony.anim.EASE
                },
                "opacity": 1
            }
        }), {
            "delay": 0,
            "iterationCount": 1,
            "fillMode": kony.anim.FILL_MODE_FORWARDS,
            "duration": 0.25
        }, {
            // "animationEnd": STYLE_ACTION____dbd2e4289ee444f48896a916e58bd9b4_Callback
        });
        this.view.segData.setEnabled(true);
        //this.view.segData.rowSkin="seq2Normal";
    },
    animationOpacity0: function() {
        this.view.flxSearch.animate(kony.ui.createAnimation({
            "100": {
                "stepConfig": {
                    "timingFunction": kony.anim.EASE
                },
                "opacity": 0
            }
        }), {
            "delay": 0,
            "iterationCount": 1,
            "fillMode": kony.anim.FILL_MODE_FORWARDS,
            "duration": 1,
            "direction": kony.anim.DIRECTION_ALTERNATE
        }, {
            //"animationEnd": this.aimationOpacity
        });
    },
    animateSearch: function() {
        this.view.flxSearch.animate(kony.ui.createAnimation({
            "100": {
                "stepConfig": {
                    "timingFunction": kony.anim.EASE
                },
                "top": "8%"
            }
        }), {
            "delay": 0,
            "iterationCount": 1,
            "fillMode": kony.anim.FILL_MODE_FORWARDS,
            "duration": 0.25,
            "direction": kony.anim.DIRECTION_ALTERNATE
        }, {});
        this.view.flxMain.animate(kony.ui.createAnimation({
            "100": {
                "stepConfig": {
                    "timingFunction": kony.anim.EASE
                },
                "top": "16%"
            }
        }), {
            "delay": 0,
            "iterationCount": 1,
            "fillMode": kony.anim.FILL_MODE_FORWARDS,
            "duration": 0.25,
            "direction": kony.anim.DIRECTION_ALTERNATE
        }, {});
    },
    goHome: function() {
        categoryId = ' ';
        this.getCategories();
    },
    goSearch: function() {
        searchTxt = this.view.txtSearch.text;
        var navigationObject = new kony.mvc.Navigation("frmProducts");
        var navigationContext = {
            "searchTxt": searchTxt,
            "searchBy": "SEARCHTXT"
        };
        navigationObject.navigate(navigationContext);
        kony.application.destroyForm("frmMain");
    },
    //******************
    reFreshWithRowAnim: function() {
        // var data = this.view.segData.data;
        // alert(JSON.stringify("Data > "+ data));
        // var addRowAnim=this.getAddRowAnim();
        // this.view.segData.addAll(data,addRowAnim);
        //this.view.segData.addAll(data);
        this.onRowDisplayFunction();
    },
    //   getAddRowAnim:function(){
    //     var transformProp1 = kony.ui.makeAffineTransform();
    //     transformProp1.scale(0.0,0.0); 
    //     var transformProp2 = kony.ui.makeAffineTransform();
    //     transformProp2.scale(0.5,0.5);
    //     var transformProp3 = kony.ui.makeAffineTransform();
    //     transformProp3.scale(1,1);
    //     var animDefinitionOne = {0  : {"anchorPoint":{"x":0.5,"y":0.5},"transform":transformProp1},
    //                              // 50 : {"anchorPoint":{"x":0.5,"y":0.5},"transform":transformProp2},
    //                              100 : {"anchorPoint":{"x":0.5,"y":0.5},"transform":transformProp3}
    //                             } ;
    //     var animObj=kony.ui.createAnimation(animDefinitionOne);
    //     var animConf={delay:0,fillMode:kony.anim.FILL_MODE_FORWARDS,duration:0.7};
    //     var addRowAnimtion = { definition : animObj, config : animConf, callbacks : null };
    //     return addRowAnimtion;
    //   },
    onRowDisplayFunction: function() {
        var transformObj1 = kony.ui.makeAffineTransform();
        transformObj1.translate(250, 0);
        var transformObj2 = kony.ui.makeAffineTransform();
        transformObj2.translate(0, 0);
        var animationObject = kony.ui.createAnimation({
            "0": {
                "transform": transformObj1,
                "stepConfig": {
                    "timingFunction": kony.anim.LINEAR
                }
            },
            "100": {
                "transform": transformObj2,
                "stepConfig": {
                    "timingFunction": kony.anim.LINEAR
                }
            }
        });
        var animationConfig = {
            duration: 1,
            fillMode: kony.anim.FILL_MODE_FORWARDS
        };
        var animationDefObject = {
            definition: animationObject,
            config: animationConfig
        };
        this.view.segData.setAnimations({
            visible: animationDefObject
        });
    },
});
define("frmMainControllerActions", {
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** onDone defined for txtSearch **/
    AS_TextField_b353877479be4573b320057480c035e6: function AS_TextField_b353877479be4573b320057480c035e6(eventobject, changedtext) {
        var self = this;
        return self.goSearch.call(this);
    },
    /** onTouchStart defined for lblCancelSearch **/
    AS_Label_ada3081453ef4e7ca3b5f78df87cb09a: function AS_Label_ada3081453ef4e7ca3b5f78df87cb09a(eventobject, x, y) {
        var self = this;
        return self.cancelSearch.call(this);
    },
    /** onTouchStart defined for imgLogo **/
    AS_Image_a1daf5135fc949f591e5ea0b696983a4: function AS_Image_a1daf5135fc949f591e5ea0b696983a4(eventobject, x, y) {
        var self = this;
        return self.goHome.call(this);
    },
    /** onTouchStart defined for imgSearch **/
    AS_Image_g475e7ec1f754c3384179850424a02ef: function AS_Image_g475e7ec1f754c3384179850424a02ef(eventobject, x, y) {
        var self = this;
        self.searchProduct.call(this);
    },
    /** onTouchStart defined for imgBack **/
    AS_Image_f09267e962ce4d99b33d59d40254904f: function AS_Image_f09267e962ce4d99b33d59d40254904f(eventobject, x, y) {
        var self = this;
        return self.previousForm.call(this);
    },
    /** onRowClick defined for segData **/
    AS_Segment_ebf3d6063c3f43e5ae1d805ad77eb285: function AS_Segment_ebf3d6063c3f43e5ae1d805ad77eb285(eventobject, sectionNumber, rowNumber) {
        var self = this;
        return self.showDetailsOfSelectedRow.call(this);
    },
    /** init defined for frmMain **/
    AS_Form_b69f9f94b39c41c985e58539f70ae06d: function AS_Form_b69f9f94b39c41c985e58539f70ae06d(eventobject) {
        var self = this;
        return self.getCategories.call(this);
    },
    /** postShow defined for frmMain **/
    AS_Form_e57f0f11d0534358b2126d203a924a0b: function AS_Form_e57f0f11d0534358b2126d203a924a0b(eventobject) {
        var self = this;
        return self.reFreshWithRowAnim.call(this);
    },
    /** onDeviceBack defined for frmMain **/
    AS_Form_adcf127c62bc4094aa87e14347551077: function AS_Form_adcf127c62bc4094aa87e14347551077(eventobject) {
        var self = this;
        return self.previousForm.call(this);
    },
    /** onDeviceBack defined for frmMain **/
    AS_Form_f2902228c64f4f848eb7440268c336e6: function AS_Form_f2902228c64f4f848eb7440268c336e6(eventobject) {
        var self = this;
    },
    /** onDeviceBack defined for frmMain **/
    AS_Form_f7cd907ff16845ed89b5c723f273d295: function AS_Form_f7cd907ff16845ed89b5c723f273d295(eventobject) {
        var self = this;
        return self.previousForm.call(this);
    }
});
define("frmMainController", ["userfrmMainController", "frmMainControllerActions"], function() {
    var controller = require("userfrmMainController");
    var controllerActions = ["frmMainControllerActions"];
    return kony.visualizer.mixinControllerActions(controller, controllerActions);
});
