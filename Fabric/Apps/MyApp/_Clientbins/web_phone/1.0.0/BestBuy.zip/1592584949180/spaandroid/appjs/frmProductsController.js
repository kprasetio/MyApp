var searchTxt = " ";
var searchBy = " ";
var products;
var categoryName;
var alternateCategoryId;
var alternateCategoryName;
define("userfrmProductsController", {
    //Type your controller code here 
    onNavigate: function(eventobject) {
        this.view.segData.setVisibility(false);
        this.view.ComHeader.imgSearch.setVisibility(false);
        searchBy = eventobject.searchBy;
        //alert("previousForm "+JSON.stringify(previousForm));  
        if (searchBy === "SEARCHTXT") {
            searchTxt = eventobject.searchTxt;
            this.view.lblTitle.text = 'Results for: ' + searchTxt;
            // alert("searchTxt >" + JSON.stringify(searchTxt)); 
            this.getProductsByText();
        } else if (searchBy === "CATEGORYID") {
            searchTxt = eventobject.categoryId;
            categoryName = eventobject.categoryName;
            alternateCategoryId = eventobject.alternateCategoryId;
            alternateCategoryName = eventobject.alternateCategoryName;
            //alert("searchTxt >" + JSON.stringify(searchTxt)); 
            this.view.lblTitle.text = 'Category : ' + eventobject.categoryName;
            this.getProductsForCategory();
            //if (products.length===0){
            //alert("masuk sini");
            // 	searchTxt = eventobject.alternateCategoryId;
            //this.view.lblTitle.text = 'alternateCategory : '+ searchTxt;
            //this.getProductsForCategory();
            //}
        }
    },
    getProductsForCategory: function() {
        if (searchTxt !== " ") {
            var integrationServiceObject = kony.sdk.getCurrentInstance().getIntegrationService("BestBuyService");
            var headers = {};
            var input = {
                "categoryPathId": searchTxt
            };
            integrationServiceObject.invokeOperation("getProductsForCategory", headers, input, this.getProductsSuccessCallback.bind(this), this.getProductsFailurCallback.bind(this));
            this.view.ComHeader.imgBack.setVisibility(true);
        } else {
            alert("Search Field is Empty!");
        }
    },
    getProductsByText: function() {
        if (searchTxt !== " ") {
            var integrationServiceObject = kony.sdk.getCurrentInstance().getIntegrationService("BestBuyService");
            var headers = {};
            var input = {
                "searchTxt": searchTxt
            };
            integrationServiceObject.invokeOperation("getProductsBySearchText", headers, input, this.getProductsSuccessCallback.bind(this), this.getProductsFailurCallback.bind(this));
            this.view.ComHeader.imgBack.setVisibility(true);
        } else {
            alert("Search Field is Empty!");
        }
    },
    getProductsSuccessCallback: function(response) {
        if (response.opstatus === 0) {
            this.view.segData.removeAll();
            products = response.products;
            // alert("products >> "+JSON.stringify(products.length));
            if (products.length > 0) {
                var transformObject1 = kony.ui.makeAffineTransform();
                var transformObject2 = kony.ui.makeAffineTransform();
                transformObject1.scale(0, 0);
                transformObject2.scale(1, 1);
                var animationObject = kony.ui.createAnimation({
                    "0": {
                        "transform": transformObject1,
                        "stepConfig": {
                            "timingFunction": kony.anim.LINEAR
                        }
                    },
                    "100": {
                        "transform": transformObject1,
                        "stepConfig": {
                            "timingFunction": kony.anim.LINEAR
                        }
                    }
                });
                var animationConfig = {
                    duration: 1,
                    fillMode: kony.anim.FILL_MODE_FORWARDS
                };
                var animationCallbacks = {
                    "animationEnd": function() {
                        kony.print("animation END");
                    }
                };
                var animationDefObject = {
                    definition: animationObject,
                    config: animationConfig,
                    callbacks: animationCallbacks
                };
                for (let i = 0; i <= products.length - 1; i++) {
                    productId = products[i].productId;
                    productName = products[i].productName;
                    price = "";
                    onSaleFlg = false;
                    if (products[i].onSale == "false") {
                        price = "$ " + products[i].regularPrice;
                        onSaleFlg = false;
                        colorPrice = sknLblBlack;
                    } else {
                        price = "$ " + products[i].salePrice;
                        onSaleFlg = true;
                        colorPrice = sknLblRed;
                    }
                    rateFlg = false;
                    if (products[i].customerReviewAverage !== "") {
                        rateFlg = true;
                    }
                    customerReviewAverage = "Avg User Rating : " + products[i].customerReviewAverage;
                    productImage = products[i].images[0].href;
                    dataRow = {
                        flxOnSale: {
                            isVisible: onSaleFlg
                        },
                        lblOnSale: {
                            text: "!!!ON SALE!!!",
                            isVisible: onSaleFlg
                        },
                        lblProductId: productId,
                        lblProductName: productName,
                        lblProductPrice: {
                            text: price,
                            skin: colorPrice
                        },
                        flxProductRate: {
                            isVisible: rateFlg
                        },
                        lblProductRate: customerReviewAverage,
                        imgProduct: productImage
                    };
                    this.view.segData.addDataAt(dataRow, i, animationDefObject);
                }
                this.view.segData.setVisibility(true);
            } else {
                //alert("kok ga ada");
                // var strconfirm =  confirm("Product not found! Do you want to see product list of parent category?");
                // if (strconfirm===true) {
                searchTxt = alternateCategoryId;
                this.view.lblTitle.text = 'Category : ' + alternateCategoryName;
                this.getProductsForCategory();
                //	} else {
                // Do nothing!
                //	}
            }
        } else {
            alert("Error in perfoming the service call at Fabric!");
        }
    },
    getProductsFailurCallback: function(error) {
        alert("Failur > " + JSON.stringify(error));
    },
    previousForm: function() {
        this.goHome();
    },
    searchProduct: function() {
        var navigationObject = new kony.mvc.Navigation("frmSearch");
        var navigationContext = {};
        navigationObject.navigate(navigationContext);
    },
    goDetailProduct: function() {
        var selectRowItems = this.view.segData.selectedRowItems;
        productId = selectRowItems[0].lblProductId;
        if (productId === '' || productId === null) {
            alert("Detail Product Not Found!");
        } else {
            var navigationObject = new kony.mvc.Navigation("frmProductDetail");
            var navigationContext = {
                "searchTxt": searchTxt,
                "productId": productId,
                "searchBy": searchBy,
                "categoryId": categoryId,
                "categoryName": categoryName,
                "alternateCategoryId": alternateCategoryId,
                "alternateCategoryName": alternateCategoryName
            };
            navigationObject.navigate(navigationContext);
        }
    },
    goHome: function() {
        var navigationObject = new kony.mvc.Navigation("frmMain");
        var navigationContext = {};
        navigationObject.navigate(navigationContext);
    },
    //*************************
    reFreshWithRowAnim: function() {
        //// var data = this.view.segData.data;
        // var addRowAnim=this.getAddRowAnim();
        // this.view.segData.addAll(data,addRowAnim);
        this.onRowDisplayFunction();
    },
    // 	 getAddRowAnim:function(){
    //       var transformProp1 = kony.ui.makeAffineTransform();
    //       transformProp1.scale(0.0,0.0); 
    //       var transformProp2 = kony.ui.makeAffineTransform();
    //       transformProp2.scale(0.5,0.5);
    //       var transformProp3 = kony.ui.makeAffineTransform();
    //       transformProp3.scale(1,1);
    //       var animDefinitionOne = {0  : {"anchorPoint":{"x":0.5,"y":0.5},"transform":transformProp1},
    //                                // 50 : {"anchorPoint":{"x":0.5,"y":0.5},"transform":transformProp2},
    //                                100 : {"anchorPoint":{"x":0.5,"y":0.5},"transform":transformProp3}
    //                               } ;
    //       var animObj=kony.ui.createAnimation(animDefinitionOne);
    //       var animConf={delay:0,fillMode:kony.anim.FILL_MODE_FORWARDS,duration:0.7};
    //       var addRowAnimtion = { definition : animObj, config : animConf, callbacks : null };
    //       return addRowAnimtion;
    //     },
    onRowDisplayFunction: function() {
        var animConfig = {
            "duration": 1.5,
            "iterationCount": 1,
            "delay": 0,
            "fillMode": kony.anim.FORWARDS
        };
        //scale
        var transformProp1 = kony.ui.makeAffineTransform();
        transformProp1.scale(0.0, 0.0);
        var transformProp3 = kony.ui.makeAffineTransform();
        transformProp3.scale(1, 1);
        var animDefinitionOne = {
            0: {
                "anchorPoint": {
                    "x": 0.5,
                    "y": 0.5
                },
                "transform": transformProp1
            },
            100: {
                "anchorPoint": {
                    "x": 0.5,
                    "y": 0.5
                },
                "transform": transformProp3
            }
        };
        var animDefinition = kony.ui.createAnimation(animDefinitionOne);
        var finalAnimation = {
            definition: animDefinition,
            config: animConfig
        };
        this.view.segData.setAnimations({
            visible: finalAnimation
        });
    },
});
define("frmProductsControllerActions", {
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** onTouchStart defined for imgLogo **/
    AS_Image_ccf6a28d86c54c2eb61cee3f13bcd29a: function AS_Image_ccf6a28d86c54c2eb61cee3f13bcd29a(eventobject, x, y) {
        var self = this;
        return self.goHome.call(this);
    },
    /** onTouchStart defined for imgSearch **/
    AS_Image_i6cb295f8f3d43988703f3c6cee67937: function AS_Image_i6cb295f8f3d43988703f3c6cee67937(eventobject, x, y) {
        var self = this;
        return self.searchProduct.call(this);
    },
    /** onDownloadComplete defined for imgBack **/
    AS_Image_ge602884c22f4f9d82bff28884254b4f: function AS_Image_ge602884c22f4f9d82bff28884254b4f(eventobject, imagesrc, issuccess) {
        var self = this;
    },
    /** onTouchStart defined for imgBack **/
    AS_Image_j8b7a5ebd9cd46ed9ead55326326da8a: function AS_Image_j8b7a5ebd9cd46ed9ead55326326da8a(eventobject, x, y) {
        var self = this;
        return self.previousForm.call(this);
    },
    /** onRowClick defined for segData **/
    AS_Segment_g8f91896cac040a29b5f54e797273e8c: function AS_Segment_g8f91896cac040a29b5f54e797273e8c(eventobject, sectionNumber, rowNumber) {
        var self = this;
        return self.goDetailProduct.call(this);
    },
    /** postShow defined for frmProducts **/
    AS_Form_bcc1349149224cf3a608cd99c3714d01: function AS_Form_bcc1349149224cf3a608cd99c3714d01(eventobject) {
        var self = this;
        return self.reFreshWithRowAnim.call(this);
    },
    /** onNavigate defined for frmProducts **/
    onNavigate: function AS_Form_i3899ab972394ea3aa311c222a21c2c3(eventobject) {
        var self = this;
        return self.onNavigate.call(this, null);
    },
    /** onDeviceBack defined for frmProducts **/
    AS_Form_g0798779b3564d87a73ebd0a798ae83c: function AS_Form_g0798779b3564d87a73ebd0a798ae83c(eventobject) {
        var self = this;
        return self.previousForm.call(this);
    },
    /** onDeviceBack defined for frmProducts **/
    AS_Form_a1d8d87314e049cda856187c2997144d: function AS_Form_a1d8d87314e049cda856187c2997144d(eventobject) {
        var self = this;
        return self.previousForm.call(this);
    }
});
define("frmProductsController", ["userfrmProductsController", "frmProductsControllerActions"], function() {
    var controller = require("userfrmProductsController");
    var controllerActions = ["frmProductsControllerActions"];
    return kony.visualizer.mixinControllerActions(controller, controllerActions);
});
